<p>Detailed Package Installer</p>
<p>A checkbox on the Ready page allows you to disable index updates while items from the package are installed.</p>
<p>The status of the installation is indicated with a progress bar and a message indicating the number and percent of items that have been installed.</p>
<p>Logging will be temporarily set to the INFO level (if it is not already) and messages about the installation will be displayed.</p>